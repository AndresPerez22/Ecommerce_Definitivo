﻿using E_Commerce_Project.Models;

namespace E_Commerce_Project.Data
{
    public static class DataSeeder
    {
        public static void Seed(ApplicationDbContext context)
        {
            // ✅ Traemos todos los productos existentes
            var existentes = context.Productos
                .Select(p => p.Nombre.Trim().ToLower())
                .ToList();

            // ✅ Lista de productos iniciales
            var productos = new List<Producto>
            {
                new Producto { Nombre = "Toyota Land Cruiser Series 70", Descripcion = "Para el trabajo pesado no se arruga.", Precio = 300000000, ImagenUrl = "/images/vEHICULOS 1.jpg" },
                new Producto { Nombre = "Toyota TXL", Descripcion = "Versatibilidad y comodidad con mucha robustes.", Precio = 490000000, ImagenUrl = "/images/Vehiculo 2.jpg" },
                new Producto { Nombre = "Mzda CX-30", Descripcion = "Diseñadas para máxima velocidad y eficiencia.", Precio = 154000000, ImagenUrl = "/images/Vehiculo 3.jpg" },
                new Producto { Nombre = "Mercdes Benz GLC 300", Descripcion = "estilo, lujo y calidad Alemana.", Precio = 310000000, ImagenUrl = "/images/Vehiculo 4.jpg" },
                new Producto { Nombre = "Chevrolet Tahoe", Descripcion = "Mucho esitlo americano, grande y sin ahorros.", Precio = 326000000, ImagenUrl = "/images/Vehiculo 5.jpg" },
                new Producto { Nombre = "Renault Stepway", Descripcion = "Economico, perfecto para ciudad y trabajar.", Precio = 87000000, ImagenUrl = "/images/Vehiculo 6.jpg" },
                new Producto { Nombre = "Ford Fiesta", Descripcion = "Versatil, economico, no apto para reservados.", Precio = 70000000, ImagenUrl = "/images/Vehiculo 7.jpg" },
                new Producto { Nombre = "Mercedes Benz Clase G", Descripcion = "Exclusiva, versatil y elegante.", Precio = 750000000, ImagenUrl = "/images/clase g.png" },
                new Producto { Nombre = "Audio A8", Descripcion = "Modelo icónico y atemporal.", Precio = 210000000, ImagenUrl = "/images/Audio A8.png" },
                new Producto { Nombre = "Ford Escape", Descripcion = "Perfecto para la familia.", Precio = 130000000, ImagenUrl = "/images/Escape.png" },
                new Producto { Nombre = "Toyota Hilux", Descripcion = "Es un reto acabar con ella.", Precio = 320000000, ImagenUrl = "/images/Hilux.png" },
                new Producto { Nombre = "Subaru Impreza", Descripcion = "El mejor estilo Japones.", Precio = 190000000, ImagenUrl = "/images/Impreza .png" },
                new Producto { Nombre = "volkswagen Jetta", Descripcion = "Un clasico de confiabilidad.", Precio = 130000000, ImagenUrl = "/images/Jetta.png" },
                new Producto { Nombre = "BMW M3", Descripcion = "Tecnología e innovacion juntos.", Precio = 230000000, ImagenUrl = "/images/M3.png" },
                new Producto { Nombre = "Mazda 2", Descripcion = "Veloz y economico.", Precio = 120000000, ImagenUrl = "/images/Mazda 2.png" },
                new Producto { Nombre = "Mercedez benz GLE 53", Descripcion = "Confort y elegancia .", Precio = 250000000, ImagenUrl = "/images/Mercedez benz GLE 53.png" },
                new Producto { Nombre = "Ford Raptor", Descripcion = "Perfecta para terrenos Dificles.", Precio = 420000000, ImagenUrl = "/images/Raptor.png" },
                new Producto { Nombre = "Chevrolet Onix", Descripcion = "Economico y Veloz.", Precio = 93000000, ImagenUrl = "/images/Onix.png" },
                new Producto { Nombre = "Ford Ranger", Descripcion = "Amortiguación icónica con estilo futurista.", Precio = 170000000, ImagenUrl = "/images/Ranger.png" },
                new Producto { Nombre = "NIssan Sentra", Descripcion = "Comodidad ajustable y ligero.", Precio = 120000000, ImagenUrl = "/images/sentra.png" }
            };

            // ✅ Solo agregar los que no existan ya (comparando en minúsculas)
            var nuevos = productos
                .Where(p => !existentes.Contains(p.Nombre.Trim().ToLower()))
                .ToList();

            if (nuevos.Any())
            {
                context.Productos.AddRange(nuevos);
                context.SaveChanges();
                Console.WriteLine($"🟢 Se agregaron {nuevos.Count} productos nuevos.");
            }
            else
            {
                Console.WriteLine("ℹ️ Todos los productos ya existen, no se agregaron duplicados.");
            }
        }
    }
}

