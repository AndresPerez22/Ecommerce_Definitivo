﻿namespace E_Commerce_Project.Models
{
    public class Categoria
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}
