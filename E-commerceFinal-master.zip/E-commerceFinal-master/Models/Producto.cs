﻿using System.ComponentModel.DataAnnotations;

namespace E_Commerce_Project.Models
{
    public class Producto
    {
        public int Id { get; set; }

        [Required]
        public string Nombre { get; set; }

        public string? Descripcion { get; set; }

        [Required]
        public decimal Precio { get; set; }

        public string? ImagenUrl { get; set; }
    }
}

