﻿using Microsoft.EntityFrameworkCore;
using E_Commerce_Project.Data; // 👈 Importante, para que encuentre ApplicationDbContext

var builder = WebApplication.CreateBuilder(args);

// ✅ Configurar DbContext con MySQL
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        new MySqlServerVersion(new Version(8, 0, 33)) // Cambia a tu versión real de MySQL
    )
);

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();
// 👇 Agregar datos iniciales si no existen
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    // 🔥 Forzamos limpieza y reinserción de datos
    context.Database.EnsureDeleted();
    context.Database.EnsureCreated();

    Console.WriteLine("🟢 Ejecutando DataSeeder...");
    DataSeeder.Seed(context);
    Console.WriteLine("✅ DataSeeder completado");
}


// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
    