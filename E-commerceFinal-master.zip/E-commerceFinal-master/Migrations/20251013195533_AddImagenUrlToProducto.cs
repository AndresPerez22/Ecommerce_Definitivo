﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace E_Commerce__Project.Migrations
{
    public partial class AddImagenUrlToProducto : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
